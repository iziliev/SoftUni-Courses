public class P01_Calculate_Expression {
    public static void main(String[] args) {
        double sum = (30 + 21) * 0.5 * (35 - 12 - 0.5);
        double pow = Math.pow(sum,2);

        System.out.println(pow);
    }
}
