function solve(arr){

    let num1 = Number(arr[0]);
    let num2 = Number(arr[1]);
    
    let sum = num1+num2;
    
    console.log(sum);
    
}

solve(['10', '20']);
solve(['66', '4']);