function solve(){
    let num = ((30 + 25) * 1/3 * (35 - 14 - 12));

    let pow = Math.pow(num,2);

    console.log(pow);
}

solve();