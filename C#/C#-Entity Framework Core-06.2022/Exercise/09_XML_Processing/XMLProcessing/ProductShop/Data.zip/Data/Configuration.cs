﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Data
{
    public class Configuration
    {
        public static string connection = @"Server=.;Database=ProductShopXML;User Id=sa; Password=Ilievi84;Encrypt=false;";
    }
}
