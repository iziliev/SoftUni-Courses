﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Footballers.Data.Models.Enums
{
    public enum BestSkillType
    {
        Defence, 
        Dribble, 
        Pass, 
        Shoot, 
        Speed
    }
}
