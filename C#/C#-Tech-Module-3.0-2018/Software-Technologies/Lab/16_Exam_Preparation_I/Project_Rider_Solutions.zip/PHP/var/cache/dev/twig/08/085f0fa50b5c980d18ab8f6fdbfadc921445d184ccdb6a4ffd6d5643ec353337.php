<?php

/* project/delete.html.twig */
class __TwigTemplate_85ae76799aa902121d904ff4705dd86426681fa0ac797e936ddd69f5ad1724f2 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "project/delete.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "project/delete.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "project/delete.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <div class=\"wrapper\">
        <form class=\"project-create\" method=\"post\">
            <div class=\"create-header\">
                Delete Project
            </div>
            <div class=\"create-title\">
                <div class=\"create-title-label\">Title</div>
                <input class=\"create-title-content\" name=\"project[title]\" value=\"";
        // line 11
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["project"]) || array_key_exists("project", $context) ? $context["project"] : (function () { throw new Twig_Error_Runtime('Variable "project" does not exist.', 11, $this->source); })()), "title", array()), "html", null, true);
        echo "\"  readonly/>
            </div>
            <div class=\"create-description\">
                <div class=\"create-description-label\">Description</div>
                <textarea rows=\"3\" class=\"create-description-content\" name=\"project[description]\" readonly
                >";
        // line 16
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["project"]) || array_key_exists("project", $context) ? $context["project"] : (function () { throw new Twig_Error_Runtime('Variable "project" does not exist.', 16, $this->source); })()), "description", array()), "html", null, true);
        echo "</textarea>
            </div>
            <div class=\"create-budget\">
                <div class=\"create-budget-label\">Budget</div>
                <input type=\"number\" min=\"0\" class=\"create-budget-content\" name=\"project[budget]\"
                       value=\"";
        // line 21
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["project"]) || array_key_exists("project", $context) ? $context["project"] : (function () { throw new Twig_Error_Runtime('Variable "project" does not exist.', 21, $this->source); })()), "budget", array()), "html", null, true);
        echo "\"
                      readonly/>
            </div>
            <div class=\"create-button-holder\">
                <button type=\"submit\" class=\"submit-button\">Delete Project</button>
                <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
            </div>
            ";
        // line 28
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 28, $this->source); })()), "_token", array()), 'row');
        echo "
        </form>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "project/delete.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 28,  78 => 21,  70 => 16,  62 => 11,  53 => 4,  44 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
    <div class=\"wrapper\">
        <form class=\"project-create\" method=\"post\">
            <div class=\"create-header\">
                Delete Project
            </div>
            <div class=\"create-title\">
                <div class=\"create-title-label\">Title</div>
                <input class=\"create-title-content\" name=\"project[title]\" value=\"{{ project.title }}\"  readonly/>
            </div>
            <div class=\"create-description\">
                <div class=\"create-description-label\">Description</div>
                <textarea rows=\"3\" class=\"create-description-content\" name=\"project[description]\" readonly
                >{{ project.description }}</textarea>
            </div>
            <div class=\"create-budget\">
                <div class=\"create-budget-label\">Budget</div>
                <input type=\"number\" min=\"0\" class=\"create-budget-content\" name=\"project[budget]\"
                       value=\"{{ project.budget }}\"
                      readonly/>
            </div>
            <div class=\"create-button-holder\">
                <button type=\"submit\" class=\"submit-button\">Delete Project</button>
                <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
            </div>
            {{ form_row(form._token) }}
        </form>
    </div>
{% endblock %}", "project/delete.html.twig", "C:\\Users\\iiliev\\Desktop\\Skeletons_Solutions\\PHP\\app\\Resources\\views\\project\\delete.html.twig");
    }
}
