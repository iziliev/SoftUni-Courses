﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CarWebSystem.Models.Cars
{
    public class DeleteCarViewModel
    {
        public int Id { get; set; }

        public string Car { get; set; }
    }
}
