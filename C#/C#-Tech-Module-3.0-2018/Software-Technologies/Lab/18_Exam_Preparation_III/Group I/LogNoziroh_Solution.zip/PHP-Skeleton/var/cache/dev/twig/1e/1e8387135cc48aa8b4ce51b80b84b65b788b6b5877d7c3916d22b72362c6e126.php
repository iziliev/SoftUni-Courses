<?php

/* report/delete.html.twig */
class __TwigTemplate_44229ffdfbadf24ba4a42a9b8d530a5ef5bcb451512dcc5f397fbddfd2a8fe6c extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "report/delete.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "report/delete.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "report/delete.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "<div class=\"wrapper\">
    <form class=\"report-create\" method=\"post\">
        <div class=\"create-header\">
            Archive Report
        </div>
        <div class=\"create-status\">
            <div class=\"create-status-label\">Status</div>
            <div class=\"create-status-content\">
                <input type=\"radio\" id=\"normal-status\" name=\"report[status]\" value=\"Normal\" ";
        // line 12
        echo (((twig_get_attribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new Twig_Error_Runtime('Variable "report" does not exist.', 12, $this->source); })()), "status", array()) == "Normal")) ? ("checked") : (""));
        echo " disabled/>
                <label for=\"normal-status\">Normal</label>
                <input type=\"radio\" id=\"warning-status\" name=\"report[status]\" value=\"Warning\" ";
        // line 14
        echo (((twig_get_attribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new Twig_Error_Runtime('Variable "report" does not exist.', 14, $this->source); })()), "status", array()) == "Warning")) ? ("checked") : (""));
        echo " disabled/>
                <label for=\"warning-status\">Warning</label>
                <input type=\"radio\" id=\"critical-status\" name=\"report[status]\" value=\"Critical\" ";
        // line 16
        echo (((twig_get_attribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new Twig_Error_Runtime('Variable "report" does not exist.', 16, $this->source); })()), "status", array()) == "Critical")) ? ("checked") : (""));
        echo " disabled/>
                <label for=\"critical-status\">Critical</label>
            </div>
        </div>
        <div class=\"create-message\">
            <div class=\"create-message-label\">Message</div>
            <textarea rows=\"3\" class=\"create-message-content\" name=\"report[message]\" disabled>";
        // line 22
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new Twig_Error_Runtime('Variable "report" does not exist.', 22, $this->source); })()), "message", array()), "html", null, true);
        echo "</textarea>
        </div>
        <div class=\"create-origin\">
            <div class=\"create-origin-label\">Origin</div>
            <textarea rows=\"3\" class=\"create-origin-content\" name=\"report[origin]\" disabled>";
        // line 26
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new Twig_Error_Runtime('Variable "report" does not exist.', 26, $this->source); })()), "origin", array()), "html", null, true);
        echo "</textarea>
        </div>
        <div class=\"create-button-holder\">
            <button type=\"submit\" class=\"submit-button\">Archive Report</button>
            <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
        </div>

        ";
        // line 33
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 33, $this->source); })()), "_token", array()), 'row');
        echo "
    </form>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "report/delete.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 33,  89 => 26,  82 => 22,  73 => 16,  68 => 14,  63 => 12,  53 => 4,  44 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
<div class=\"wrapper\">
    <form class=\"report-create\" method=\"post\">
        <div class=\"create-header\">
            Archive Report
        </div>
        <div class=\"create-status\">
            <div class=\"create-status-label\">Status</div>
            <div class=\"create-status-content\">
                <input type=\"radio\" id=\"normal-status\" name=\"report[status]\" value=\"Normal\" {{ report.status == 'Normal' ? 'checked' : '' }} disabled/>
                <label for=\"normal-status\">Normal</label>
                <input type=\"radio\" id=\"warning-status\" name=\"report[status]\" value=\"Warning\" {{ report.status == 'Warning' ? 'checked' : '' }} disabled/>
                <label for=\"warning-status\">Warning</label>
                <input type=\"radio\" id=\"critical-status\" name=\"report[status]\" value=\"Critical\" {{ report.status == 'Critical' ? 'checked' : '' }} disabled/>
                <label for=\"critical-status\">Critical</label>
            </div>
        </div>
        <div class=\"create-message\">
            <div class=\"create-message-label\">Message</div>
            <textarea rows=\"3\" class=\"create-message-content\" name=\"report[message]\" disabled>{{report.message}}</textarea>
        </div>
        <div class=\"create-origin\">
            <div class=\"create-origin-label\">Origin</div>
            <textarea rows=\"3\" class=\"create-origin-content\" name=\"report[origin]\" disabled>{{report.origin}}</textarea>
        </div>
        <div class=\"create-button-holder\">
            <button type=\"submit\" class=\"submit-button\">Archive Report</button>
            <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
        </div>

        {{ form_row(form._token) }}
    </form>
</div>
{% endblock %}", "report/delete.html.twig", "C:\\Users\\iiliev\\Desktop\\18_Exam_Preparation_III\\Group I\\LogNoziroh\\PHP-Skeleton\\app\\Resources\\views\\report\\delete.html.twig");
    }
}
