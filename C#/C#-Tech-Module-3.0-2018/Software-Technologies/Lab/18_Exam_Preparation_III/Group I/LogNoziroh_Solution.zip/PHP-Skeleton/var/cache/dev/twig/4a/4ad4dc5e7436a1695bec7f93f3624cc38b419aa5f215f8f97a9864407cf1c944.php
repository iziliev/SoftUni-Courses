<?php

/* report/details.html.twig */
class __TwigTemplate_fa02f031d94e8bb98d3fb64cbd4901b7f10b0334ffc8be66abc6ee0ccec97625 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "report/details.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "report/details.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "report/details.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "<div class=\"wrapper\">
    <div class=\"report-details\">
        <div class=\"details-header\">
            Report Details
        </div>
        <div class=\"details-status\">
            <div class=\"details-status-label\">Status</div>
            <div class=\"details-status-content\">";
        // line 11
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new Twig_Error_Runtime('Variable "report" does not exist.', 11, $this->source); })()), "status", array()), "html", null, true);
        echo "</div>
        </div>
        <div class=\"details-message\">
            <div class=\"details-message-label\">Message</div>
            <div class=\"details-message-content\">
                ";
        // line 16
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new Twig_Error_Runtime('Variable "report" does not exist.', 16, $this->source); })()), "message", array()), "html", null, true);
        echo "
            </div>
        </div>
        <div class=\"details-origin\">
            <div class=\"details-origin-label\">Origin</div>
            <div class=\"details-origin-content\">
                ";
        // line 22
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["report"]) || array_key_exists("report", $context) ? $context["report"] : (function () { throw new Twig_Error_Runtime('Variable "report" does not exist.', 22, $this->source); })()), "origin", array()), "html", null, true);
        echo "
            </div>
        </div>
    </div>
    <div class=\"details-button-holder\">
        <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
    </div>
</div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "report/details.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 22,  70 => 16,  62 => 11,  53 => 4,  44 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
<div class=\"wrapper\">
    <div class=\"report-details\">
        <div class=\"details-header\">
            Report Details
        </div>
        <div class=\"details-status\">
            <div class=\"details-status-label\">Status</div>
            <div class=\"details-status-content\">{{report.status}}</div>
        </div>
        <div class=\"details-message\">
            <div class=\"details-message-label\">Message</div>
            <div class=\"details-message-content\">
                {{report.message}}
            </div>
        </div>
        <div class=\"details-origin\">
            <div class=\"details-origin-label\">Origin</div>
            <div class=\"details-origin-content\">
                {{report.origin}}
            </div>
        </div>
    </div>
    <div class=\"details-button-holder\">
        <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
    </div>
</div>
{% endblock %}", "report/details.html.twig", "C:\\Users\\iiliev\\Desktop\\18_Exam_Preparation_III\\Group I\\LogNoziroh\\PHP-Skeleton\\app\\Resources\\views\\report\\details.html.twig");
    }
}
