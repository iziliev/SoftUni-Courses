const Task = require('../models').Task;

module.exports = {
    index: (req, res) => {
        \\TODO
    },
    createGet: (req, res) => {
        \\TODO
    },
    createPost: (req, res) => {
        \\TODO
    },
    editGet: (req, res) => {
        \\TODO
    },
    editPost: (req, res) => {
        \\TODO
    }
};