package imdb.bindingModel;

public class FilmBindingModel {

    // TODO

}
