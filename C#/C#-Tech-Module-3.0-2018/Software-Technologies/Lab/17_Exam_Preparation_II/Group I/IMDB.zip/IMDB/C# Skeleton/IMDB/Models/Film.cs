﻿namespace IMDB.Models
{
    using System.ComponentModel.DataAnnotations;

    public class Film
    {
        // TODO
    }
}
