const Sequelize = require('sequelize');

module.exports = function(sequelize){
    // TODO
};