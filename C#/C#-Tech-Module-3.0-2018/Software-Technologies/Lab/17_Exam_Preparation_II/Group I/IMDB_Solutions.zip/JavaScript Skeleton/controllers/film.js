const Film = require('../models').Film;

module.exports = {
	index: (req, res) => {
        let films = Film.findAll().then(films=>{
            res.render("film/index", {"films": films})
        });
	},

	createGet: (req, res) => {
        res.render("film/create");
	},

	createPost: (req, res) => {
        let args = req.body;
        Film.create(args).then(()=>{
            res.redirect("/");
        }).catch(err=>{
        	console.log(err.message);
		})
	},

	editGet: (req, res) => {
        let id = req.params.id;

        Film.findById(id).then(film=>{

            // 1. You can added all stuff to view like that
            /*
            	{
            		"id": id
            		"name": film.name,
                	"genre": film.genre,
                	"director": film.director,
                	"year": film.year,
                }
            */

            // 2. Or you can use method dataValues
            // film.dataValues

            res.render("film/edit",film.dataValues);
        }).catch(err=>{
        	console.log(err.message);
		})
	},

	editPost: (req, res) => {
        let id = req.params.id;
        let args = req.body;

        Film.findById(id).then(film=>{
        	film.updateAttributes(args).then(()=>{
        		res.redirect("/")
			})
		})
	},

	deleteGet: (req, res) => {
        let id = req.params.id;

        Film.findById(id).then(film=>{
            res.render("film/delete",film.dataValues);
		})
	},

	deletePost: (req, res) => {
        let id = req.params.id;

        Film.findById(id).then(film=>{
            film.destroy().then(()=>{
                res.redirect("/")
            })
        })
	}
};