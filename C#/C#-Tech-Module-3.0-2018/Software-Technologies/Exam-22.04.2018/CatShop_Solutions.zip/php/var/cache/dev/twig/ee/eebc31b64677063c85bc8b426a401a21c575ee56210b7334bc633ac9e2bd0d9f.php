<?php

/* cat/create.html.twig */
class __TwigTemplate_ac6446259c51f292009fdd1ee80f395abc45dab9938f1e3a2271e64ddb3a0538 extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "cat/create.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "cat/create.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "cat/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <div class=\"wrapper\">
        <form class=\"cat-create\" method=\"post\">
            <div class=\"create-header\">
                Add Cat
            </div>
            <div class=\"create-name\">
                <div class=\"create-name-label\">Name</div>
                <input class=\"create-name-content\" name=\"cat[name]\" />
            </div>
            <div class=\"create-nickname\">
                <div class=\"create-nickname-label\">Nickname</div>
                <input class=\"create-nickname-content\" name=\"cat[nickname]\"/>
            </div>
            <div class=\"create-price\">
                <div class=\"create-price-label\">Price</div>
                <input type=\"number\" min=\"0\" step=\"0.00001\" class=\"create-price-content\" name=\"cat[price]\" />
            </div>
            <div class=\"create-button-holder\">
                <button type=\"submit\" class=\"submit-button\">Add Cat</button>
                <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
            </div>
            ";
        // line 25
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new Twig_Error_Runtime('Variable "form" does not exist.', 25, $this->source); })()), "_token", array()), 'row');
        echo "
        </form>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "cat/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  76 => 25,  53 => 4,  44 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
    <div class=\"wrapper\">
        <form class=\"cat-create\" method=\"post\">
            <div class=\"create-header\">
                Add Cat
            </div>
            <div class=\"create-name\">
                <div class=\"create-name-label\">Name</div>
                <input class=\"create-name-content\" name=\"cat[name]\" />
            </div>
            <div class=\"create-nickname\">
                <div class=\"create-nickname-label\">Nickname</div>
                <input class=\"create-nickname-content\" name=\"cat[nickname]\"/>
            </div>
            <div class=\"create-price\">
                <div class=\"create-price-label\">Price</div>
                <input type=\"number\" min=\"0\" step=\"0.00001\" class=\"create-price-content\" name=\"cat[price]\" />
            </div>
            <div class=\"create-button-holder\">
                <button type=\"submit\" class=\"submit-button\">Add Cat</button>
                <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
            </div>
            {{ form_row(form._token) }}
        </form>
    </div>
{% endblock %}", "cat/create.html.twig", "E:\\Exam-22.04.2018\\php\\app\\Resources\\views\\cat\\create.html.twig");
    }
}
