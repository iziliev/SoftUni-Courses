<?php

/* cat/index.html.twig */
class __TwigTemplate_87e630a3d34a9dd2d99044c6659c95ee7713c7decc133a854f880f22f173915d extends Twig_Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "cat/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "cat/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "cat/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "    <div class=\"wrapper\">
        <div class=\"cat-create\">
            <div class=\"create-header\">
                Cat Shop
            </div>
        </div>
        <br>
        <div class=\"button-holder\">
            <a type=\"button\" href=\"/create\" class=\"log-button\">Add Cat</a>
        </div>
        <div class=\"content\">
            <div class=\"header\">
                <div class=\"cat-label\">Cat</div>
                <div class=\"nickname-label\">Nickname</div>
                <div class=\"price-label\">Price</div>
                <div class=\"actions-label\">Actions</div>
            </div>
            <div class=\"main\">
                ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cats"]) || array_key_exists("cats", $context) ? $context["cats"] : (function () { throw new Twig_Error_Runtime('Variable "cats" does not exist.', 22, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["cat"]) {
            // line 23
            echo "                    <div class=\"cat\">
                        <div class=\"cat-name\">
                            ";
            // line 25
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["cat"], "name", array()), "html", null, true);
            echo "
                        </div>
                        <div class=\"cat-nickname\">
                            ";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["cat"], "nickname", array()), "html", null, true);
            echo "
                        </div>
                        <div class=\"cat-price\">
                            ";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["cat"], "price", array()), "html", null, true);
            echo "
                        </div>
                        <div class=\"cat-actions\">
                            <a type=\"button\" href=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("edit", array("id" => twig_get_attribute($this->env, $this->source, $context["cat"], "id", array()))), "html", null, true);
            echo "\" class=\"edit-button\">Edit</a>
                            <a type=\"button\" href=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("delete", array("id" => twig_get_attribute($this->env, $this->source, $context["cat"], "id", array()))), "html", null, true);
            echo "\" class=\"delete-button\">Delete</a>
                        </div>
                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['cat'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "            </div>
        </div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "cat/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  113 => 39,  103 => 35,  99 => 34,  93 => 31,  87 => 28,  81 => 25,  77 => 23,  73 => 22,  53 => 4,  44 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
    <div class=\"wrapper\">
        <div class=\"cat-create\">
            <div class=\"create-header\">
                Cat Shop
            </div>
        </div>
        <br>
        <div class=\"button-holder\">
            <a type=\"button\" href=\"/create\" class=\"log-button\">Add Cat</a>
        </div>
        <div class=\"content\">
            <div class=\"header\">
                <div class=\"cat-label\">Cat</div>
                <div class=\"nickname-label\">Nickname</div>
                <div class=\"price-label\">Price</div>
                <div class=\"actions-label\">Actions</div>
            </div>
            <div class=\"main\">
                {% for cat in cats %}
                    <div class=\"cat\">
                        <div class=\"cat-name\">
                            {{ cat.name }}
                        </div>
                        <div class=\"cat-nickname\">
                            {{ cat.nickname }}
                        </div>
                        <div class=\"cat-price\">
                            {{ cat.price }}
                        </div>
                        <div class=\"cat-actions\">
                            <a type=\"button\" href=\"{{ path('edit', {id: cat.id}) }}\" class=\"edit-button\">Edit</a>
                            <a type=\"button\" href=\"{{ path('delete', {id: cat.id}) }}\" class=\"delete-button\">Delete</a>
                        </div>
                    </div>
                {% endfor %}
            </div>
        </div>
    </div>
{% endblock %}", "cat/index.html.twig", "E:\\Exam-22.04.2018\\php\\app\\Resources\\views\\cat\\index.html.twig");
    }
}
