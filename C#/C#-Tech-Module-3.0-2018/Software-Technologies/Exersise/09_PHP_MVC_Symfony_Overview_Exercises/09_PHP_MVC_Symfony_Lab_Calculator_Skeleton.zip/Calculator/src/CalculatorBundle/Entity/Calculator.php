<?php
namespace CalculatorBundle\Entity;

class Calculator
{

    // TODO add class fields and properties, getters and setters

}