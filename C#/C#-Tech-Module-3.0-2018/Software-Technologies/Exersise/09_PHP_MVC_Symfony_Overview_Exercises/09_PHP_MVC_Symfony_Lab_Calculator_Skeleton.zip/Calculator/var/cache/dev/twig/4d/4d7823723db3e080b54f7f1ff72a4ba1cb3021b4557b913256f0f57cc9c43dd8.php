<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_99b2a225cb70aa4a8d48984f92fa0c34ec0fea32a96ff1e63d94ed7465a2ded8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cbfac7f5742f3ccf99164237be49f0020dc6a270b003a16d2fe9a385e8166f23 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cbfac7f5742f3ccf99164237be49f0020dc6a270b003a16d2fe9a385e8166f23->enter($__internal_cbfac7f5742f3ccf99164237be49f0020dc6a270b003a16d2fe9a385e8166f23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_d2af655300d194e5fdf14cf09a90a52cd429985a68d37c938ec28a442471588a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d2af655300d194e5fdf14cf09a90a52cd429985a68d37c938ec28a442471588a->enter($__internal_d2af655300d194e5fdf14cf09a90a52cd429985a68d37c938ec28a442471588a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cbfac7f5742f3ccf99164237be49f0020dc6a270b003a16d2fe9a385e8166f23->leave($__internal_cbfac7f5742f3ccf99164237be49f0020dc6a270b003a16d2fe9a385e8166f23_prof);

        
        $__internal_d2af655300d194e5fdf14cf09a90a52cd429985a68d37c938ec28a442471588a->leave($__internal_d2af655300d194e5fdf14cf09a90a52cd429985a68d37c938ec28a442471588a_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_3940350e373d881d9208fbee03138943e1a4f1973aa99faf20d3b6942de2902f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3940350e373d881d9208fbee03138943e1a4f1973aa99faf20d3b6942de2902f->enter($__internal_3940350e373d881d9208fbee03138943e1a4f1973aa99faf20d3b6942de2902f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_ed77faf4e98b8a1554dfac75bec1bd134d2184c790002cbb7be62240ebbef9e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed77faf4e98b8a1554dfac75bec1bd134d2184c790002cbb7be62240ebbef9e3->enter($__internal_ed77faf4e98b8a1554dfac75bec1bd134d2184c790002cbb7be62240ebbef9e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_ed77faf4e98b8a1554dfac75bec1bd134d2184c790002cbb7be62240ebbef9e3->leave($__internal_ed77faf4e98b8a1554dfac75bec1bd134d2184c790002cbb7be62240ebbef9e3_prof);

        
        $__internal_3940350e373d881d9208fbee03138943e1a4f1973aa99faf20d3b6942de2902f->leave($__internal_3940350e373d881d9208fbee03138943e1a4f1973aa99faf20d3b6942de2902f_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_c9c256433fcbcd5ff9248b9fe4a7d86c659c80540c3c21ef529a70947022af75 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c9c256433fcbcd5ff9248b9fe4a7d86c659c80540c3c21ef529a70947022af75->enter($__internal_c9c256433fcbcd5ff9248b9fe4a7d86c659c80540c3c21ef529a70947022af75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_5a6e0f8c76345a95524dbe37c4a5991e378b01b78033e14c77106b5032ab0730 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a6e0f8c76345a95524dbe37c4a5991e378b01b78033e14c77106b5032ab0730->enter($__internal_5a6e0f8c76345a95524dbe37c4a5991e378b01b78033e14c77106b5032ab0730_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_5a6e0f8c76345a95524dbe37c4a5991e378b01b78033e14c77106b5032ab0730->leave($__internal_5a6e0f8c76345a95524dbe37c4a5991e378b01b78033e14c77106b5032ab0730_prof);

        
        $__internal_c9c256433fcbcd5ff9248b9fe4a7d86c659c80540c3c21ef529a70947022af75->leave($__internal_c9c256433fcbcd5ff9248b9fe4a7d86c659c80540c3c21ef529a70947022af75_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_4bc79457b1508ec6386ea6e1885c543f57511024f2c7ffe0552e326d25ec8b4a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4bc79457b1508ec6386ea6e1885c543f57511024f2c7ffe0552e326d25ec8b4a->enter($__internal_4bc79457b1508ec6386ea6e1885c543f57511024f2c7ffe0552e326d25ec8b4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_f96c17535c221b9a8d394bbeba039dac47cc2c471c5449b555ed4bc88b77e961 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f96c17535c221b9a8d394bbeba039dac47cc2c471c5449b555ed4bc88b77e961->enter($__internal_f96c17535c221b9a8d394bbeba039dac47cc2c471c5449b555ed4bc88b77e961_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_f96c17535c221b9a8d394bbeba039dac47cc2c471c5449b555ed4bc88b77e961->leave($__internal_f96c17535c221b9a8d394bbeba039dac47cc2c471c5449b555ed4bc88b77e961_prof);

        
        $__internal_4bc79457b1508ec6386ea6e1885c543f57511024f2c7ffe0552e326d25ec8b4a->leave($__internal_4bc79457b1508ec6386ea6e1885c543f57511024f2c7ffe0552e326d25ec8b4a_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\Users\\paunov\\Desktop\\php\\Calculator-Skeleton\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
